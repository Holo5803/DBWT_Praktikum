<?php


    $meal = [
        [   'name' => 'Rindfleisch mit Bambus, Kaiserschotten und rotem Paprika, dazu Mie Nudeln',
             'preis_intern' => '3,50',
             'preis_extern' => '6,20',
             'img' => 'Mie Nudeln.jpg'
        ],

        [   'name' => 'Spinatristto mit kleinen Samosateigecken und gemischter Salat',
            'preis_intern' => '2,90',
            'preis_extern' => '5,30',
            'img' => 'Spinatrisotto.jpg'
        ],

        [   'name' => 'Gulasch mit Spätzle und Paprika',
            'preis_intern' => '6,20',
            'preis_extern' => '8.20',
            'img' => "Gulasch.jpg"
        ],

        [   'name' => 'Bun Bo Hue',
            'preis_intern' => '7,50',
            'preis_extern' => '10,50',
            'img' => 'Bun bo.jpg'
        ]
    ];

