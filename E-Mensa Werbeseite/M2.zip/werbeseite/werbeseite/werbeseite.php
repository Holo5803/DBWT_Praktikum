<?php
global $meal;
global $confirmationMessage;
session_start();
if (!isset($_SESSION['anmeldung'])) {
    $_SESSION['anmeldung'] = 0;
}
?>

<!DOCTYPE html>
<!--
    - Praktikum DBWT. Autoren:
    - Andreas, Hüpgen, 3679869
    - Viet Minh Duc, Nguyen, 3659300
    -->
<?php include "meals.php" ?>
<?php include "formular.php" ?>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Ihre E-Mensa</title>
    <link href="werbeseite_styling.css" rel="stylesheet">
</head>
<body >
<?php
//Besucher zählen
if (!isset($_SESSION['aufrufen'])) {
    $_SESSION['aufrufen'] = 0;
}
$_SESSION['aufrufen']++;

$speisenzaehler=0;
foreach ($meal as $gericht) {
    $speisenzaehler++;
}
?>


<header>

    <logo><img src ="logo mensa.jpg"></logo>

    <nav>
        <ul>
            <li><a href="#Ankuendigung">Ankündigung</a></li>
            <li><a href="#Speisen">Speisen</a></li>
            <li><a href="#Zahlen">Zahlen</a></li>
            <li><a href="#Kontakt">Kontakt</a></li>
            <li><a href="#W.F.U">Wichtig für uns</a></li>
        </ul>
    </nav>
</header>

        <main>
            <div id ="foto"><img src ="mensa foto.jpg" alt ="Mensa Foto" class="center"></div>

            <div class ="ankuedigung">
                <h1 id="Ankuendigung">Bald gibt es Essen auch online &#59;)</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tincidunt rhoncus tortor, vel faucibus dui rutrum vitae. Morbi vitae posuere justo. Cras lobortis sodales mattis. Suspendisse vulputate velit sapien, et consectetur massa vulputate id. Praesent elementum elit ipsum, sed rutrum nulla sodales non. Nunc tempor scelerisque ipsum, ut molestie justo condimentum sit amet. Cras et erat elit. Fusce volutpat finibus condimentum. Quisque sodales porttitor nibh faucibus pretium. Duis lobortis nibh semper sem tempor faucibus. Aliquam cursus, nisi nec consequat pulvinar, turpis odio ultricies lectus, sit amet vehicula massa orci in nulla. Mauris mattis iaculis nulla vitae feugiat. Nunc sed laoreet lectus. Suspendisse laoreet tortor vitae elit commodo auctor.</p>
            </div>

            <div class ="speisen">
                <h1 id="Speisen">Köstlichkeiten, die Sie warten</h1>
                <table id="meinetabelle">
                    <thead>
                    <tr>
                        <th>Vorschaubild</th>
                        <th>Gerichte</th>
                        <th>Preis intern</th>
                        <th>Preis extern</th>

                    </tr>
                    </thead>
                    <tbody>


                    <?php
                    foreach ($meal as $gerichte) {
                        echo "<tr>";
                        echo "<td><img src = \"{$gerichte['img']}\" width =\"100\" height =\"80\"></td>";
                        echo "<td>".$gerichte['name']."</td>";
                        echo "<td>".$gerichte['preis_intern']."</td>";
                        echo "<td>".$gerichte['preis_extern']."</td>";
                        echo "</tr>";
                    }
                    ?>



                    </tbody>
                </table>
            </div>

            <div class = "zahlen">
                <h1 id="Zahlen">E-Mensa in Zahlen</h1>
                <ul>
                    <li><?php echo $_SESSION['aufrufen']?> Besuche </li>
                    <li><?php echo $_SESSION['anmeldung']?> Anmeldungen zum Newsletter</li>
                    <li><?php echo $speisenzaehler ?> Speisen </li>
                </ul>
            </div>

            <div class="kontakt">
                <h1 id="Kontakt">Interesse geweckt? Wir informieren Sie!</h1>
                <form class="formular" action ="" method="POST">
                    <fieldset>
                        <div>
                            <label for="vorname">Ihr Name:</label>
                            <input type ="text" id="vorname" name="vorname" placeholder="Vorname" required>
                        </div>

                        <div>
                            <label for ="email">Ihre Email:</label>
                            <input type ="text" id="email" name="email" placeholder="beispiel@.com" required>
                        </div>
                        <div>
                            <label for ="sprache">Newsletter bitte in:</label>
                            <select id="sprache" name="sprache">
                                <option value="deutsch">Deutsch</option>
                                <option value="englisch">Englisch</option>
                                <option value="spanisch">Spanisch</option>
                            </select>
                        </div>

                        <div class="checkbox">
                        <input type ="checkbox" id="datenschutz" name="datenschutz" value="datenschutz gelesen" required>
                        <label for="datenschutz"> Den Datenschutzbestimmungen stimme ich zu </label> <br>
                        </div>

                        <div class="submit"><input type="submit" value="Zum Newsletter anmelden"></div>

                    </fieldset>
                </form>
                <?php echo $confirmationMessage;?>
            </div>

            <div class ="wichtig">
                <h1 id="W.F.U" >Das ist uns wichtig</h1>
                <ul>
                    <li>Beste frische saisonale Zutaten</li>
                    <li>Ausgewogene abwechslungsreiche Gerichte</li>
                    <li>Sauberkeit</li>
                </ul>
            </div>

            <h1>Wir freuen uns auf Ihren Besuch!</h1>

            <footer>
                <ul>
                    <li>&copy; E-Mensa GmbH</li>
                    <li>Viet Minh Duc Nguyen und Andreas Huepgen</li>
                    <li><a href="#Impressum">Impressum</a></li>

                </ul>

            </footer>

        </main>




</body>
</html>