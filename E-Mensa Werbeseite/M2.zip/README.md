
# Praktikum DBWT M2
 
Autoren:

    - Andreas, Hüpgen, 3679869

    - Viet Minh Duc, Nguyen, 3659300
   



