<?php
/**
 * Praktikum DBWT. Autoren:
 * Andreas, Hüpgen, 3679869
 * Viet Minh Duc, Nguyen, 3659300
 */
include ('m2_6a_standardparameter.php');

echo addieren(3, 4);
echo addieren(3, 5);
echo addieren(100, 6);

?>