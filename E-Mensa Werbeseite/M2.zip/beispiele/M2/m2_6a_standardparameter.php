<?php
/**
 * Praktikum DBWT. Autoren:
 * Andreas, Hüpgen, 3679869
 * Viet Minh Duc, Nguyen, 3659300
 */
function addition($a, $b=0){
    return $a + $b;

}

function multiply($a, $b=0){
    return $a * $b;
}
?>