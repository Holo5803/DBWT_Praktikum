<?php
/**
 * Praktikum DBWT. Autoren:
 * Andreas, Hüpgen, 3679869
 * Viet Minh Duc, Nguyen, 3659300
 */
echo "str_repeat";
echo str_repeat("repeat", 10);

echo "str_replace";
echo str_replace("gesucht wort", "ersetz Wort", "Das hier ist gesucht wort");

echo "substr";
echo substr("Hallo Welt",6, 2);

echo "trim";
$str = " Hello World ";
echo "Without trim : [" . $str . "]";
echo "<br>";
echo "With trim: [" . trim($str ). "]";


echo "ltrim";
$str1 = " Hello World ";
echo "Without trim : [" . $str . "]";
echo "<br>";
echo "With trim: [" . ltrim($str ). "]";

echo "rtrim";
$str2 = " Hello World ";
echo "Without trim : [" . $str . "]";
echo "<br>";
echo "With trim: [" . rtrim($str ). "]";

echo "String-Konkatenation";
$a = "Hallo";
$b = "Welt";
$c = $a . $b;
echo $c;