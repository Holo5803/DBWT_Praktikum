<?php
/**
 * Praktikum DBWT. Autoren:
 * Andreas, Hüpgen, 3679869
 * Viet Minh Duc, Nguyen, 3659300
 */
include ('m2_6a_standardparameter.php');

echo addition(3, 4);
echo addition(3, 5);
echo addition(100, 6);

?>